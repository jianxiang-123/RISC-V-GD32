#include "Arduino.h"


class EXMCClass
{
private:
    /* data */
public:
    EXMCClass(uint32_t cmdPtrAddr, uint32_t datPtrAddr);
    ~EXMCClass();
    void begin();
    void end();
    uint8_t transfer(uint8_t data);
    uint16_t transfer16(uint16_t data);
    uint8_t command(uint8_t cmd);
    void transfer(void *buf, uint32_t count);
private:
    volatile uint16_t*  cmdPtr;
    volatile uint16_t*  datPtr;
};

